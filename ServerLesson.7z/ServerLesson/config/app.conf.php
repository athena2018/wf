<?php 

return [
    'db' => [
        'driver' => 'mysql',
        'host' => 'localhost',
        'dbname' => 'register',
        'dbuser' => 'root',
        'dbpass' => null 
    ]
];
